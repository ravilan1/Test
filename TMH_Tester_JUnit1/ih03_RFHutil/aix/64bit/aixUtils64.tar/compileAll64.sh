#!/bin/bash
#
#compile all programs on AIX for 64-bit
#

/usr/vac/bin/cc -q64 -I/usr/mqm/inc -c comsubs.c
/usr/vac/bin/cc -q64 -I/usr/mqm/inc -c parmline.c
/usr/vac/bin/cc -q64 -I/usr/mqm/inc -c putparms.c
/usr/vac/bin/cc -q64 -I/usr/mqm/inc -c qsubs.c
/usr/vac/bin/cc -q64 -I/usr/mqm/inc -c rfhsubs.c
/usr/vac/bin/cc -q64 -I/usr/mqm/inc -c timesubs.c
/usr/vac/bin/cc -q64 -I/usr/mqm/inc -c mqcapone.c
/usr/vac/bin/cc -q64 -I/usr/mqm/inc -c mqcapture.c
/usr/vac/bin/cc -q64 -I/usr/mqm/inc -c mqcapsub.c
/usr/vac/bin/cc -q64 -I/usr/mqm/inc -c mqput2.c
/usr/vac/bin/cc -q64 -I/usr/mqm/inc -DNOTUNE -c mqput2.c -o mqputs.o
/usr/vac/bin/cc -q64 -I/usr/mqm/inc -c mqlatency.c
/usr/vac/bin/cc -q64 -I/usr/mqm/inc -c mqreply.c
/usr/vac/bin/cc -q64 -I/usr/mqm/inc -c mqtest.c
/usr/vac/bin/cc -q64 -I/usr/mqm/inc -c mqtimes.c
/usr/vac/bin/cc -q64 -I/usr/mqm/inc -c mqtimes2.c
/usr/vac/bin/cc -q64 -I/usr/mqm/inc -c mqtimes3.c
/usr/vac/bin/cc -q64 -o mqcapone mqcapone.o comsubs.o parmline.o putparms.o qsubs.o rfhsubs.o timesubs.o -L/usr/mqm/lib64 -L/usr/mqm/lib64 -lmqm -b64 -b64
/usr/vac/bin/cc -q64 -o mqcapture mqcapture.o comsubs.o parmline.o putparms.o qsubs.o rfhsubs.o timesubs.o -L/usr/mqm/lib64 -lmqm -b64
/usr/vac/bin/cc -q64 -o mqcapsub mqcapsub.o comsubs.o parmline.o putparms.o qsubs.o rfhsubs.o timesubs.o -L/usr/mqm/lib64 -lmqm -b64
/usr/vac/bin/cc -q64 -o mqlatency mqlatency.o comsubs.o parmline.o putparms.o qsubs.o rfhsubs.o timesubs.o -L/usr/mqm/lib64 -lmqm -b64
/usr/vac/bin/cc -q64 -o mqput2 mqput2.o comsubs.o parmline.o putparms.o qsubs.o rfhsubs.o timesubs.o -L/usr/mqm/lib64 -lmqm -b64
/usr/vac/bin/cc -q64 -o mqputs mqputs.o comsubs.o parmline.o putparms.o qsubs.o rfhsubs.o timesubs.o -L/usr/mqm/lib64 -lmqm -b64
/usr/vac/bin/cc -q64 -o mqreply mqreply.o comsubs.o parmline.o putparms.o qsubs.o rfhsubs.o timesubs.o -L/usr/mqm/lib64 -lmqm -b64
/usr/vac/bin/cc -q64 -o mqtest mqtest.o comsubs.o parmline.o putparms.o qsubs.o rfhsubs.o timesubs.o -L/usr/mqm/lib64 -lmqm -b64
/usr/vac/bin/cc -q64 -o mqtimes mqtimes.o -L/usr/mqm/lib64 -lmqm -b64
/usr/vac/bin/cc -q64 -o mqtimes2 mqtimes2.o comsubs.o parmline.o putparms.o qsubs.o rfhsubs.o timesubs.o -L/usr/mqm/lib64 -lmqm -b64
/usr/vac/bin/cc -q64 -o mqtimes3 mqtimes3.o comsubs.o parmline.o putparms.o qsubs.o rfhsubs.o timesubs.o -L/usr/mqm/lib64 -lmqm -b64
