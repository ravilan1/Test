rm aixUtils64.tar
tar -cvf aixUtils64.tar -L fileNames64.txt
